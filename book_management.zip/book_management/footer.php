<div class="footer">
    <p>© 2025 Book Management System</p>
</div>
