<?php
session_start();
include("connection.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $result = mysqli_query($link, "SELECT * FROM users WHERE (email='$email' OR username='$email') AND password='$password'");
    if (mysqli_num_rows($result) == 1) {
        $_SESSION["user"] = $email;
        header("Location: dashboard.php");
        exit();
    } else {
        $message = "Sai email hoặc mật khẩu!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Đăng nhập</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Mật khẩu" required><br>
        <button type="submit">Đăng nhập</button>
    </form>
    <p class="error"><?= $message ?></p>
    <p>Chưa có tài khoản? <a href="signup.php">Đăng ký ngay</a></p>
</div>
</body>
</html>
